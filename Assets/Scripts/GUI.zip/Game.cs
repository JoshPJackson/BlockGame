﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Game.GUI;
using Game.Blocks;
using Game.Chunks;
using Game.Textures;

namespace Game {
    public class Game : MonoBehaviour
    {
        public bool debugMode = false;

        public DebugGUI debugGUI;

        public GameObject debugGUIObject;

        public WorldBuilder world;

        public TextureAtlasMapper mapper;

        public static Game currentGame;

        // Start is called before the first frame update
        void Start()
        {
            mapper = new TextureAtlasMapper();
            currentGame = this;
            setUpDebug();
            setUpCamera();
            
            world = new WorldBuilder();
            world.Generate();
            world.Render();
        }

        // Update is called once per frame
        void Update()
        {
            debugGUIObject.SetActive(debugMode);
        }

        void setUpDebug()
        {
            debugGUIObject = new GameObject("Debug GUI");
            debugGUIObject.AddComponent<DebugGUI>();
        }

        void setUpCamera()
        {
            GameObject camera = GameObject.Find("Main Camera");
            camera.AddComponent<FirstPersonCamera>();
        }
    }
}