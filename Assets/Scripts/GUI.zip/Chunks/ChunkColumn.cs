﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Chunks
{
    public class ChunkColumn
    {
        public Vector2 localPosition;

        public Vector3 globalPosition;

        public static int chunksPerColumn = 1;

        public Chunk[] chunks;

        public ChunkColumn()
        {
            chunks = new Chunk[chunksPerColumn];
        }

        public WorldBuilder parent;

        public void SetChunk(Chunk chunk, int position)
        {
            chunks[position] = chunk;
        }

        public void Render()
        {
            for (int i = 0; i < chunks.Length; i++)
            {
                if (chunks[i].GetType() == typeof(Chunk))
                {
                    chunks[i].Render();
                }
            }
        }
    }
}