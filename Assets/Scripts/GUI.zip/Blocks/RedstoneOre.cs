﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Blocks
{
    public class RedstoneOre : Block
    {
        public override string[] textureNames => new string[1] { "redstone_ore" };
    }
}
