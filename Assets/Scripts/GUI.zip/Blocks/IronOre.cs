﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Blocks
{
    public class IronOre : Block
    {
        public override string[] textureNames => new string[1] { "iron_ore" };
    }
}
