﻿using System.Collections;
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using Game.Chunks;
using Game.Blocks;

public class WorldBuilder
{
    // size of world (chunk column units)
    public Vector2 Size { get; set; }

    private Vector3 Offset { get; set; }

    public ChunkColumn[,] chunkColumns;

    public int worldMagnitude;

    public int heightLimit;

    public WorldBuilder()
    {
        Size = new Vector3(1, 1);
        Offset = Vector3.zero;
        chunkColumns = new ChunkColumn[(int) Size.x, (int) Size.y];
        worldMagnitude = (int) Size.x * Chunk.size;
        heightLimit = ChunkColumn.chunksPerColumn * Chunk.size;
    }

    public void Generate()
    {
        float minMagnitude = 1;
        float maxMagnitude = 0;

        float smoothness = 0.4f;

        for (int i = 0; i < Size.x; i++)
        {
            for (int j = 0; j < Size.y; j++)
            {
                ChunkColumn chunkColumn = new ChunkColumn();
                chunkColumn.localPosition = new Vector2(i, j);
                chunkColumn.globalPosition = new Vector3(
                    i * Chunk.size,
                    0,
                    j * Chunk.size
                );
                chunkColumn.parent = this;

                for (int k = 0; k < ChunkColumn.chunksPerColumn; k++)
                {
                    Chunk chunk = new Chunk();
                    chunk.parent = chunkColumn;
                    chunk.localPosition = k;
                    chunk.globalPosition = new Vector3(
                        chunkColumn.globalPosition.x,
                        Chunk.size * k,
                        chunkColumn.globalPosition.z
                    );
                    
                    for (int l = 0; l < Chunk.size; l++)
                    {
                        for (int m = 0; m < Chunk.size; m++)
                        {
                            for (int n = 0; n < Chunk.size; n++)
                            {

                                Block block;
                                
                                Vector3 positionInChunk = new Vector3(l, m, n);
                                Vector3 position = positionInChunk + chunk.globalPosition;
                                int maxHeight = 50 + (int) (50 * Mathf.PerlinNoise(position.x / worldMagnitude, position.z / worldMagnitude));
                                float magnitude = PerlinNoise3d.Make(position / (worldMagnitude * smoothness));                    

                                if (magnitude > maxMagnitude)
                                {
                                    maxMagnitude = magnitude;
                                }

                                if (magnitude < minMagnitude)
                                {
                                    minMagnitude = magnitude;
                                }

                                block = BlockDecider(magnitude, position.y, maxHeight);
         
                                block.chunk = chunk;
                                block.positionInChunk = positionInChunk;
                                block.globalPosition = position;
                                chunk.blocks[l, m, n] = block;
                            }
                        }
                    }

                    chunkColumn.chunks[k] = chunk;
               }
                
                chunkColumns[i, j] = chunkColumn;
            }
        }

        Debug.Log(maxMagnitude);
        Debug.Log(minMagnitude);
    }

    public void Render()
    {
        for (int x = 0; x < Size.x; x++)
        {
            for (int y = 0; y < Size.y; y++)
            {
                if (chunkColumns[x, y].GetType() == typeof(ChunkColumn))
                {
                    chunkColumns[x, y].Render();
                }
            }
        }
    }

    public Block GetBlockAtGlobalPosition(Vector3 position)
    {
        // position of block inside chunk
        int u_b, v_b, w_b;

        // global position of chunk
        int x_c, y_c, z_c;

        // postion of chunk inside chunk column
        int p_c;

        // position of chunkColumn inside world
        int u_cc, v_cc;

        // global position of chunk column
        int x_cc, z_cc;

        // find position of block inside chunk
        u_b = (int) position.x % Chunk.size;
        v_b = (int) position.y % Chunk.size;
        w_b = (int) position.z % Chunk.size;

        // find global position of chunk
        x_c = (int) position.x - u_b;
        y_c = (int) position.y - v_b;
        z_c = (int) position.z - w_b;

        // find position of chunk inside chunk column
        p_c = y_c / Chunk.size;

        // find global position of chunk column; 
        x_cc = x_c;
        z_cc = z_c;

        // find local position of chunk column inside world
        u_cc = x_cc / Chunk.size;
        v_cc = z_cc / Chunk.size;

        return (Block) chunkColumns[u_cc, v_cc].chunks[p_c].blocks[u_b, v_b, w_b];
    }

    public Block BlockDecider(float magnitude, float height, int maxHeight)
    {
        // Magnitude is a normal distribution with sigma = 0.09 and mu = 0.47
        Block block;
       
        // is bedrock
        if (height == 0)
        {
            return new Bedrock();
        }

        // is air
        if (height > maxHeight)
        {
            return new Air();
        }

        block = new Stone();

        /////////////////////////////////
        // NOT HEIGHT DEPENDENT BLOCKS //
        /////////////////////////////////

        // coal (not height dependent)
        if (magnitude <= 0.3)
        {
            return new CoalOre();
        }

        // iron ore (not height dependent)
        if (magnitude >= 0.75)
        {
            return new IronOre();
        }

        /////////////////////////////////
        //// HEIGHT DEPENDENT BLOCKS ////
        /////////////////////////////////
        
        // obsidian generation
        if (height > 0 && height <= 2)
        {
            if (magnitude >= 0.4 && magnitude < 0.6)
            {
                return new Obsidian();
            }
        }

        // diamond/redstone/lapis generation 
        if (height > 0 && height <= 20)
        {
            if (magnitude <= 0.31) // 1.89%
            {
                return new RedstoneOre();
            }

            if (magnitude <= 0.33) // 1.29%
            {
                return new DiamondOre();
            }

            if (magnitude <= 0.35) // 2.13
            {
                return new LapisLazuli();
            }

            if (magnitude <= 0.37) // 3.24
            {
                return new EmeraldOre();
            }

            if (magnitude <= 0.38) //2.03
            {
                return new RubyOre();
            }
        }
        
        // gold
        if (height > 0 && height < 60)
        {
            if (magnitude < 0.31)
            {
                return new GoldOre();
            }
        }


        // deal with top 10 layers (grass/dirt/stone)
        if (height >= maxHeight - 10)
        {
            if (magnitude > 0.6 || magnitude < 0.2)
            {
                return new Stone();
            } else
            {
                if (height == maxHeight)
                {
                    return new Grass();
                }

                return new Dirt();
            }
        }

        return block;
    }
}
