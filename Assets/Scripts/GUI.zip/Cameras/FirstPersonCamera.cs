﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonCamera : MonoBehaviour
{
    public float speed = 0.0f;

    public float maxSpeed = 10.0f;

    public float mouseSensitivity = 0.4f;

    private Vector3 mouseStart;

    // Start is called before the first frame update
    void Start()
    {
        gameObject.AddComponent<Rigidbody>();
        mouseStart = new Vector3(Screen.width/2, Screen.height/2, 0);
    }

    // Update is called once per frame
    void Update()
    {
        var view = Camera.main.ScreenToViewportPoint(Input.mousePosition);
        bool isOutside = view.x < 0 || view.x > 1 || view.y < 0 || view.y > 1;
        Rigidbody rigidbody = gameObject.GetComponent<Rigidbody>();
        rigidbody.useGravity = false;

        if (!isOutside)
        { 
            Vector3 translation = rigidbody.velocity;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                rigidbody.velocity = new Vector3(rigidbody.velocity.x, maxSpeed, rigidbody.velocity.z);
            }

            if (Input.GetKeyUp(KeyCode.Space))
            {
                rigidbody.velocity = new Vector3(rigidbody.velocity.x, 0, rigidbody.velocity.z);
            }

            if (Input.GetKeyDown(KeyCode.LeftControl))
            {
                rigidbody.velocity = new Vector3(rigidbody.velocity.x, -maxSpeed, rigidbody.velocity.z);
            }

            if (Input.GetKeyUp(KeyCode.LeftControl))
            {
                rigidbody.velocity = new Vector3(rigidbody.velocity.x, 0, rigidbody.velocity.z);
            }

            Vector3 mouseChange = new Vector3();
            mouseChange.x = -(mouseStart.x - Input.mousePosition.x);
            mouseChange.y = mouseStart.y - Input.mousePosition.y;
            rigidbody.transform.eulerAngles += mouseSensitivity * new Vector3(mouseChange.y, mouseChange.x, 0);
            mouseStart = Input.mousePosition;
            float angle = rigidbody.transform.eulerAngles.y;
            float velocityForward = 0.0f;
            float velocitySideways = 0.0f;

            if (Input.GetAxis("Mouse X") < 0 || Input.GetAxis("Mouse X") > 0)
            {
                angle = rigidbody.transform.eulerAngles.y;
                velocityForward = speed * Mathf.Sin(angle / 180 * Mathf.PI);
                velocitySideways = speed * Mathf.Cos(angle / 180 * Mathf.PI);
                rigidbody.velocity = new Vector3(velocityForward, rigidbody.velocity.y, velocitySideways);
            }
            
            if (Input.GetKeyDown(KeyCode.W))
            {
                speed = maxSpeed;
                angle = rigidbody.transform.eulerAngles.y;
                velocityForward = speed * Mathf.Sin(angle / 180 * Mathf.PI);
                velocitySideways = speed * Mathf.Cos(angle / 180 * Mathf.PI);
                rigidbody.velocity = new Vector3(velocityForward, rigidbody.velocity.y, velocitySideways);
            }

            if (Input.GetKeyUp(KeyCode.W)) {
                rigidbody.velocity = new Vector3(0, rigidbody.velocity.y, 0);
            }
        } else
        {
            rigidbody.velocity = Vector3.zero;
        }
    }


}
